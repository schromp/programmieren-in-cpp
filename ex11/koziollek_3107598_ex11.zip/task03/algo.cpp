#include <ostream>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

int main(int argc, char *argv[]) {

  std::string countodd("countodd");
  std::string hasnegative("hasnegative");
  std::string inc("inc");
  std::string sum("sum");
  std::string deleteodd("deleteodd");

}
