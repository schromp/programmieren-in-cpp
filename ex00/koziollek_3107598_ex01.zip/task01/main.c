#include <stdio.h>

int main(void)
{
    printf("Hello World \n");

    return 0; // 0=ExitCode: successfull; 1=ExitCode: etwas anderes; -1=Exitcode: error irgendetwas
}