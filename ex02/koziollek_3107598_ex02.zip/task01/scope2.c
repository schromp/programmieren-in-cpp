float globalvar;

/**
 * @brief changes globalvar to 2
 * 
 */
void modtest(void) {
    globalvar = 2;
}
